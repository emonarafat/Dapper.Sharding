﻿using Dapper.Sharding;
using System.Collections.Concurrent;

namespace TestContext
{
    public class DbContext
    {
        #region 获取Context(默认单库)

        public static readonly DbContext Default = new DbContext();

        #endregion

        #region 获取Context(分库)

        private static readonly object obj = new object();

        private static readonly ConcurrentDictionary<int, DbContext> dict = new ConcurrentDictionary<int, DbContext>();

        /// <summary>
        /// 通过缓存获取DbContext
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public static DbContext GetContext(int productId)
        {
            var ok = dict.TryGetValue(productId, out var val);
            if (!ok)
            {
                lock (obj)
                {
                    if (!dict.ContainsKey(productId))
                    {
                        dict.TryAdd(productId, new DbContext(productId));
                    }
                }
                val = dict[productId];
            }
            return val;
        }

        #endregion

        #region 构造函数

        private readonly string dbName;

        public IDatabase Db => DbConfig.Client.GetDatabase(dbName);

        //无参构造函数
        private DbContext()
        {
            dbName = DbConfig.DatabaseName;
        }

        //分库构造函数
        private DbContext(int productId)
        {
            dbName = $"{DbConfig.DatabaseName}_{productId}";
        }

        #endregion

        public ITable<People> People => Db.GetTable<People>("people");

    }
}

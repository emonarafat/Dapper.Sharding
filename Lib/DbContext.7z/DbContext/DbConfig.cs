﻿using Dapper.Sharding;
using SharpConfig;
using System;

namespace TestContext
{
    public class DbConfig
    {
        public static readonly IClient Client;

        //主数据库名称
        public static readonly string DatabaseName;

        static DbConfig()
        {
            var iniConfig = Configuration.LoadFromFile($@"{AppDomain.CurrentDomain.BaseDirectory}config\db.ini");
            var config = iniConfig["db"].ToObject<DataBaseConfig>();
            DatabaseName = iniConfig["dbname"]["name"].GetValue<string>();
            Client = ShardingFactory.CreateClient(DataBaseType.MySql, config);
            Client.AutoCompareTableColumn = true; //允许对比字段
            Client.AutoCompareTableColumnDelete = true; //允许对比删除字段
        }
    }
}

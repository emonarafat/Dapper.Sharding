﻿using Dapper.Sharding;

namespace TestContext
{
    [Table("Id")]
    public class People
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
